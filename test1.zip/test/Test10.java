package com.demo.test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test10 {
@Test
public void JsonPathUsage() throws MalformedURLException
{
	RestAssured.baseURI = "https://swapi.dev/api/people/1/?format=json";
	RequestSpecification httpRequest = RestAssured.given();
	Response response = httpRequest.get("");

	// First get the JsonPath object instance from the Response interface
	//JsonPath jsonPathEvaluator = response.jsonPath();
/*
	// Read all the books as a List of String. Each item in the list
	// represent a book node in the REST service Response
	List<String> allBooks = jsonPathEvaluator.getList("films.title");

	// Iterate over the list and print individual book item
	for(String films : allBooks)
	{
		System.out.println("Book: " + films);
	}*/
}
}