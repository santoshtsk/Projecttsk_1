package com.demo.test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.annotations.Test;

public class Test9 {
@Test
public static void test9() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium Software\\Drivers\\Chrome\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();

	driver.get("https://www.foxla.com");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.findElements(By.xpath("//*[@id='google_ads_iframe_/63790564/KTTV_FOX11/root_0']"));
	driver.findElements(By.xpath("//*[@id='hit']"));
		
}

}
