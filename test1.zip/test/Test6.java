package com.demo.test;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test6 {
@Test
public static void test6() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium Software\\Drivers\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	
	driver.get("http://the-internet.herokuapp.com/dynamic_controls");
	driver.findElement(By.xpath("//*[@id='checkbox']/input")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id='checkbox-example']/button")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id='checkbox-example']/button")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id='input-example']/button")).click();
	Thread.sleep(15000);
	//*[@id="message"]
	WebElement txtmsg=driver.findElement(By.xpath("//*[@id='message']"));
	Assert.assertEquals(true, txtmsg.isDisplayed());
	driver.findElement(By.xpath("//*[@id='input-example']/input")).click();
	Thread.sleep(25000);
	driver.findElement(By.xpath("//*[@id='input-example']/button")).click();
	Thread.sleep(25000);
	
	//*[@id="tinymce"]/p
}

}
//*[@id="content"]/div/butto