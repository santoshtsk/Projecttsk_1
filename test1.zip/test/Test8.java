package com.demo.test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.testng.annotations.Test;

public class Test8 {
@Test
public static void test8() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium Software\\Drivers\\Chrome\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();

	driver.get("https://www.foxla.com/live");
	driver.manage().window().maximize();
	List<WebElement> iframes = driver.findElements(By.tagName("iframe"));
	 System.out.println("Total number of iframes are: " + iframes.size());
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.switchTo().frame(1);
	WebElement ele=driver.findElement(By.xpath("//*[@class='anv-play-pause-btn-svg anv-control-btn-svg']"));
	Actions actions = new Actions(driver);
	actions.moveToElement(ele);
	actions.moveToElement(ele).perform();
	ele.click();
//	driver.findElement(By.xpath("//*[@class='anv-volume-icon-btn anv-control-btn anv-volume-icon-off-btn']")).click();

	
	//*[@id="gwd-ad"]
	
	
}

}
