package com.demo.test;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;
import org.testng.annotations.Test;

public class Test7 {
@Test
public static void test7() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium Software\\Drivers\\Chrome\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();

	driver.get("https://the-internet.herokuapp.com/tinymce");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.switchTo().frame("mce_0_ifr");
	driver.findElement(By.id("tinymce")).clear();
	driver.findElement(By.id("tinymce")).sendKeys("Entering testing");
	WebElement t=driver.findElement(By.id("tinymce"));
	String s = t.getCssValue("color");
    // convert rgba to hex
    String c = Color.fromString(s).asHex();
    System.out.println("Color is :" + s);
    System.out.println("Hex code for color:" + c);
}

}
