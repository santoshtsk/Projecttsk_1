package com.demo.test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test5 {
@Test
public static void test5() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium Software\\Drivers\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	
	driver.get("http://the-internet.herokuapp.com/add_remove_elements/");
	driver.findElement(By.xpath("//*[@id='content']/div/button")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id='elements']/button")).click();
	
	}

}
